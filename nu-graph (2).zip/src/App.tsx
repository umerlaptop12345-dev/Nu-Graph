import { motion } from "motion/react";
import { GlassCard } from "./components/ui/GlassCard";
import { MagneticButton } from "./components/ui/MagneticButton";
import Navbar from "./components/layout/Navbar";
import Footer from "./components/layout/Footer";
import SmoothScrolling from "./components/layout/SmoothScrolling";
import { ArrowRight, BarChart3, Zap, BrainCircuit, Play, CheckCircle2, TrendingUp, Users2, Sparkles } from "lucide-react";

export default function App() {
  return (
    <SmoothScrolling>
      <div className="relative flex flex-col min-h-screen overflow-hidden bg-brand-black text-brand-white">
        {/* Background Ambient Glows */}
        <div className="absolute top-[-100px] left-[-100px] w-[500px] h-[500px] bg-brand-blue/20 rounded-full blur-[120px] pointer-events-none -z-10"></div>
        <div className="absolute bottom-[-100px] right-[-100px] w-[500px] h-[500px] bg-brand-purple/20 rounded-full blur-[120px] pointer-events-none -z-10"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-gradient-to-r from-brand-blue/5 via-brand-purple/5 to-brand-cyan/5 blur-[80px] opacity-40 pointer-events-none -z-10"></div>
        
        <Navbar />
        
        <main className="relative">
          {/* 1. HERO SECTION */}
          <section className="relative min-h-screen flex flex-col justify-center items-center pt-32 pb-20 px-6 sm:px-12 text-center overflow-hidden">
            {/* Animated Background Elements */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-hero-glow blur-[120px] rounded-full opacity-40 animate-pulse-glow -z-20" />
            <div className="absolute inset-0 bg-noise opacity-[0.03] mix-blend-overlay -z-10" />

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="max-w-5xl mx-auto flex flex-col items-center"
            >
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-brand-purple/30 bg-brand-purple/10 text-brand-cyan text-[10px] font-bold uppercase tracking-[0.2em] mb-8 backdrop-blur-sm"
              >
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-cyan opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-brand-cyan shadow-[0_0_8px_#00E5FF]"></span>
                </span>
                Next-Gen Growth Agency
              </motion.div>

              <h1 className="text-6xl md:text-8xl font-display font-bold leading-[1.1] tracking-tight mb-6">
                Nu Graph: The <br className="hidden md:block" />
                <span className="text-white">
                  New Shape of Social.
                </span>
              </h1>

              <p className="text-lg md:text-xl text-gray-400 max-w-3xl mb-10 leading-relaxed">
                High-Performance Visual Content Strategy for <span className="text-white font-semibold">DTC Sustainability</span> and <span className="text-white font-semibold">Eco-Friendly Brands</span>. Engineering digital resonance through technical precision.
              </p>

              <div className="flex flex-col sm:flex-row items-center gap-4">
                <MagneticButton primary>Book Strategy Call</MagneticButton>
                <MagneticButton primary={false}>
                  <Play className="w-4 h-4 fill-current" /> View Showreel
                </MagneticButton>
              </div>
            </motion.div>

            {/* Scroll Indicator */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1, duration: 1 }}
              className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-gray-500"
            >
              <p className="text-[10px] uppercase tracking-[0.2em] font-bold">Scroll to explore</p>
              <div className="w-[1px] h-12 bg-gradient-to-b from-brand-purple to-transparent" />
            </motion.div>
          </section>

          {/* 2. TRUST / METRICS SECTION */}
          <section className="h-[120px] border-y border-white/[0.05] bg-brand-graphite/50 backdrop-blur-sm relative z-10 flex items-center">
            <div className="max-w-7xl mx-auto w-full px-6 grid grid-cols-2 md:grid-cols-4 gap-4 text-center divide-x divide-white/5">
              {[
                { value: "$2.4M+", label: "Revenue Generated" },
                { value: "400%", label: "Avg Engagement" },
                { value: "12M+", label: "Organic Views" },
                { value: "50+", label: "Brands Scaled" },
              ].map((stat, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1, duration: 0.6 }}
                  className="px-4"
                >
                  <h3 className="text-2xl md:text-3xl font-display font-bold text-white">{stat.value}</h3>
                  <p className="text-[10px] text-white/40 font-bold uppercase tracking-widest">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </section>

          {/* 3. SERVICES SECTION */}
          <section id="services" className="py-32 px-6 relative z-10">
            <div className="max-w-7xl mx-auto">
              <div className="mb-20 md:flex justify-between items-end">
                <div className="max-w-2xl">
                  <span className="text-brand-purple font-bold tracking-[0.3em] uppercase text-xs mb-4 block">Our Ecosystem</span>
                  <h2 className="text-4xl md:text-6xl font-display font-bold mb-6">Social Architecture.</h2>
                  <p className="text-gray-400 text-lg">We bridge the gap between creative flair and technical SEO precision.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <GlassCard>
                  <div className="p-4 rounded-2xl bg-brand-blue/10 w-fit mb-8 group-hover:scale-110 transition-transform">
                    <Sparkles className="w-8 h-8 text-brand-blue" />
                  </div>
                  <h3 className="text-2xl font-display font-bold mb-4">SEO & Content Strategy</h3>
                  <div className="space-y-4 mb-8">
                    <div>
                      <h4 className="text-white font-bold text-sm mb-1">SEO Content Writing</h4>
                      <p className="text-gray-400 text-[13px] leading-relaxed">High-quality, keyword-optimized articles and blogs designed to rank on Google while maintaining professional editorial tone.</p>
                    </div>
                    <div>
                      <h4 className="text-white font-bold text-sm mb-1">On-Page SEO Optimization</h4>
                      <p className="text-gray-400 text-[13px] leading-relaxed">Auditing search visibility through better headings, meta descriptions, and keyword density.</p>
                    </div>
                    <div>
                      <h4 className="text-white font-bold text-sm mb-1">Brand Copywriting</h4>
                      <p className="text-gray-400 text-[13px] leading-relaxed">Crafting persuasive website copy and brand stories that resonate with your target audience.</p>
                    </div>
                  </div>
                  <div className="mt-auto flex items-center gap-2 text-brand-white text-xs font-bold uppercase tracking-wider group-hover:text-brand-blue transition-colors">
                    The Content Framework <ArrowRight className="w-4 h-4" />
                  </div>
                </GlassCard>

                <GlassCard>
                  <div className="p-4 rounded-2xl bg-brand-purple/10 w-fit mb-8 group-hover:scale-110 transition-transform">
                    <Users2 className="w-8 h-8 text-brand-purple" />
                  </div>
                  <h3 className="text-2xl font-display font-bold mb-4">Social Media Management</h3>
                  <div className="space-y-4 mb-8">
                    <div>
                      <h4 className="text-white font-bold text-sm mb-1">Strategic Planning</h4>
                      <p className="text-gray-400 text-[13px] leading-relaxed">Developing 30-day content calendars aligned with business goals and brand pillars.</p>
                    </div>
                    <div>
                      <h4 className="text-white font-bold text-sm mb-1">Community Engagement</h4>
                      <p className="text-gray-400 text-[13px] leading-relaxed">Managing interactions and messages to build a loyal community around your brand.</p>
                    </div>
                    <div>
                      <h4 className="text-white font-bold text-sm mb-1">Growth Analytics</h4>
                      <p className="text-gray-400 text-[13px] leading-relaxed">Monthly reporting on reach and follower growth to refine and improve strategy.</p>
                    </div>
                  </div>
                  <div className="mt-auto flex items-center gap-2 text-brand-white text-xs font-bold uppercase tracking-wider group-hover:text-brand-purple transition-colors">
                    SMM Packages <ArrowRight className="w-4 h-4" />
                  </div>
                </GlassCard>

                <GlassCard>
                  <div className="p-4 rounded-2xl bg-brand-cyan/10 w-fit mb-8 group-hover:scale-110 transition-transform">
                    <BrainCircuit className="w-8 h-8 text-brand-cyan" />
                  </div>
                  <h3 className="text-2xl font-display font-bold mb-4">Brand Identity & Design</h3>
                  <div className="space-y-4 mb-8">
                    <div>
                      <h4 className="text-white font-bold text-sm mb-1">Visual Aesthetics</h4>
                      <p className="text-gray-400 text-[13px] leading-relaxed">Visual palettes (utilizing the 60-30-10 rule) and typography guides for absolute consistency.</p>
                    </div>
                    <div>
                      <h4 className="text-white font-bold text-sm mb-1">Social Media Kits</h4>
                      <p className="text-gray-400 text-[13px] leading-relaxed">Custom templates for Instagram, LinkedIn and Facebook header designs reflecting a "Nu" aesthetic.</p>
                    </div>
                    <div>
                      <h4 className="text-white font-bold text-sm mb-1">Brand Documentation</h4>
                      <p className="text-gray-400 text-[13px] leading-relaxed">Comprehensive guides outlining your brand’s mission, vision, and professional voice.</p>
                    </div>
                  </div>
                  <div className="mt-auto flex items-center gap-2 text-brand-white text-xs font-bold uppercase tracking-wider group-hover:text-brand-cyan transition-colors">
                    Brand Strategy <ArrowRight className="w-4 h-4" />
                  </div>
                </GlassCard>
              </div>
            </div>
          </section>

          {/* 4. CASE STUDIES (WORK) SECTION */}
          <section id="work" className="py-32 px-6 relative z-10">
            <div className="max-w-7xl mx-auto">
              <div className="mb-20 text-center">
                <span className="text-brand-blue font-bold tracking-[0.3em] uppercase text-xs mb-4 block">Proven Results</span>
                <h2 className="text-4xl md:text-6xl font-display font-bold mb-6">Market Dominance.</h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                {[
                  {
                    title: "Lumina Gear",
                    category: "Tech & E-commerce",
                    metric: "+340% Revenue",
                    image: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=2670&auto=format&fit=crop"
                  },
                  {
                    title: "Aura Skincare",
                    category: "Dapp & Web3",
                    metric: "12M+ Impressions",
                    image: "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?q=80&w=2670&auto=format&fit=crop"
                  }
                ].map((project, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, scale: 0.95 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.2 }}
                    className="group relative aspect-[16/10] rounded-3xl overflow-hidden border border-white/5 cursor-pointer"
                  >
                    <img 
                      src={project.image} 
                      alt={project.title} 
                      className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-brand-black/40 group-hover:bg-brand-black/20 transition-colors" />
                    <div className="absolute inset-0 bg-gradient-to-t from-brand-black via-transparent to-transparent" />
                    
                    <div className="absolute bottom-0 left-0 w-full p-8 translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                      <div className="flex justify-between items-end">
                        <div>
                          <p className="text-xs font-bold text-brand-cyan uppercase tracking-widest mb-2">{project.category}</p>
                          <h3 className="text-3xl font-display font-bold">{project.title}</h3>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-display font-bold text-white mb-1">{project.metric}</p>
                          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Growth Period: 6 Months</p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* 5. PROCESS SECTION */}
          <section id="process" className="py-32 px-6 bg-brand-graphite/30">
            <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
              <div>
                <span className="text-brand-cyan font-bold tracking-[0.3em] uppercase text-xs mb-4 block">Proven Methodology</span>
                <h2 className="text-4xl md:text-6xl font-display font-bold mb-8">The Brand Architecture.</h2>
                <div className="space-y-6">
                  {[
                    "Phase 01: Psychic Archetyping",
                    "Phase 02: High-Volume Creative Output",
                    "Phase 03: Algorithmic Feed Injection",
                    "Phase 04: AI-Driven Conversion Loops"
                  ].map((step, i) => (
                    <motion.div 
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1 }}
                      className="flex items-center gap-4 group cursor-default"
                    >
                      <div className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-xs font-bold text-gray-500 group-hover:border-brand-purple group-hover:text-brand-purple transition-colors">
                        0{i+1}
                      </div>
                      <span className="text-xl font-display font-medium text-gray-300 group-hover:text-white transition-colors">
                        {step}
                      </span>
                    </motion.div>
                  ))}
                </div>
              </div>
              <div className="relative">
                <div className="aspect-square rounded-3xl overflow-hidden relative group">
                  <img 
                    src="https://images.unsplash.com/photo-1635332353591-62f79029965d?q=80&w=2670&auto=format&fit=crop" 
                    alt="Creative Direction" 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-brand-black via-transparent to-transparent opacity-60" />
                  <div className="absolute bottom-8 left-8 right-8 p-6 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10">
                    <div className="flex items-center gap-3 mb-2">
                      <CheckCircle2 className="text-brand-cyan w-5 h-5" />
                      <span className="font-bold text-sm">Strategic Precision</span>
                    </div>
                    <p className="text-xs text-gray-400">Every piece of content is backed by psychological deep-dives into your target audience's desires.</p>
                  </div>
                </div>
                {/* Decorative elements */}
                <div className="absolute -top-10 -right-10 w-40 h-40 bg-brand-blue/20 blur-3xl -z-10 rounded-full" />
                <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-brand-purple/20 blur-3xl -z-10 rounded-full" />
              </div>
            </div>
          </section>

          {/* 6. ABOUT SECTION (FOUNDER) */}
          <section id="about" className="py-32 px-6 relative z-10 overflow-hidden">
            <div className="max-w-4xl mx-auto">
              <div className="text-center">
                <span className="text-brand-purple font-bold tracking-[0.3em] uppercase text-xs mb-4 block">The Architect</span>
                <h2 className="text-4xl md:text-6xl font-display font-bold mb-8">Umer Imam Maqbool.</h2>
                <div className="space-y-6 text-gray-400 text-lg leading-relaxed mb-12">
                  <p>
                    I am a Social Media Marketing professional specializing in transforming brand identities through strategic <span className="text-white underline decoration-brand-cyan/50">SEO content</span> and <span className="text-white underline decoration-brand-purple/50">high-impact visual storytelling</span>.
                  </p>
                  <p>
                    As the founder of <span className="text-white font-bold">Nu Graph</span>, I bridge the gap between technical precision and creative flair. My mission is to help <span className="text-white">DTC sustainability</span> brands navigate the evolving digital landscape with data-driven social media strategies.
                  </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto bg-white/5 p-8 rounded-3xl border border-white/10">
                  <div className="text-left">
                    <h4 className="text-white font-bold text-sm mb-3 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-brand-cyan" /> SMM & Strategy
                    </h4>
                    <ul className="text-[13px] list-disc list-inside space-y-1 text-gray-400">
                      <li>End-to-end digital campaigns</li>
                      <li>Optimizing engagement</li>
                    </ul>
                  </div>
                  <div className="text-left">
                    <h4 className="text-white font-bold text-sm mb-3 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-brand-cyan" /> Brand Design
                    </h4>
                    <ul className="text-[13px] list-disc list-inside space-y-1 text-gray-400">
                      <li>60-30-10 Aesthetic rule</li>
                      <li>Mission & Vision defining</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* 7. FINAL CTA SECTION */}
          <section className="relative py-40 px-6 overflow-hidden z-10">
            <div className="absolute inset-0 bg-brand-blue/5" />
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[1px] bg-gradient-to-r from-transparent via-brand-purple to-transparent opacity-50" />
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="max-w-4xl mx-auto text-center relative z-20"
            >
              <h2 className="text-5xl md:text-8xl font-display font-bold mb-8 tracking-tighter">
                Stop Posting, <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-blue via-brand-purple to-brand-cyan">Start Growing.</span>
              </h2>
              <p className="text-xl text-gray-400 mb-12 max-w-2xl mx-auto leading-relaxed">
                Your brand architecture starts here. Click below to view our SMM packages and claim your Q3 2026 growth slot.
              </p>
              <div className="flex flex-col items-center gap-6">
                <MagneticButton className="px-12 py-6 text-lg">
                  View SMM Packages
                </MagneticButton>
                <p className="text-xs text-gray-500 font-bold uppercase tracking-[0.3em]">Slots available for Q3 2026</p>
              </div>
            </motion.div>
          </section>
        </main>

        <Footer />

        {/* WhatsApp Floating Button */}
        <a 
          href="https://wa.me/923140008001?text=Hi%20Nu%20Graph!%20I'd%20like%20to%20discuss%20your%20social%20media%20and%20SEO%20services." 
          className="whatsapp-float animate-pulse-green" 
          target="_blank" 
          rel="noopener noreferrer"
          aria-label="Chat with us on WhatsApp"
        >
          <img 
            src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" 
            alt="WhatsApp Contact" 
            className="w-8 h-8 md:w-9 md:h-9" 
          />
        </a>
      </div>
    </SmoothScrolling>
  );
}

