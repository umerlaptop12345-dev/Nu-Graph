import { motion } from "motion/react";
import { cn } from "@/src/lib/utils";

interface Props {
  children: React.ReactNode;
  primary?: boolean;
  className?: string;
  onClick?: () => void;
}

export const MagneticButton = ({ children, primary = true, className = "", onClick }: Props) => {
  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={cn(
        "relative px-8 py-4 rounded-full font-display font-bold tracking-wide text-sm uppercase overflow-hidden group transition-all duration-300",
        primary 
          ? "bg-brand-white text-brand-black shadow-xl shadow-white/5" 
          : "bg-transparent text-brand-white border border-white/20 hover:border-white/40",
        className
      )}
    >
      {primary && (
        <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-brand-blue via-brand-purple to-brand-cyan opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10" />
      )}
      <span className={cn(
        "relative z-10 transition-colors duration-300 flex items-center justify-center gap-2",
        primary ? "group-hover:text-white" : ""
      )}>
        {children}
      </span>
    </motion.button>
  );
};
