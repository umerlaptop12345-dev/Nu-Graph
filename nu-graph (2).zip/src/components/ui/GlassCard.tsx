import { motion } from "motion/react";
import { cn } from "@/src/lib/utils";

export const GlassCard = ({ children, className = "" }: { children: React.ReactNode, className?: string }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -10, scale: 1.02 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className={cn(
        "relative group overflow-hidden rounded-2xl bg-white/[0.02] border border-white/[0.05] backdrop-blur-xl p-8 transition-all hover:bg-white/[0.04] hover:border-white/[0.1]",
        className
      )}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-brand-blue/10 to-brand-purple/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-2xl -z-10" />
      <div className="relative z-10 flex flex-col h-full">
        {children}
      </div>
    </motion.div>
  );
};
