import { ArrowRight, Instagram, Twitter, Linkedin, Github } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-brand-black border-t border-white/5 pt-24 pb-12 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-24">
          <div className="col-span-1 md:col-span-2">
            <a href="/" className="inline-flex items-center gap-2 mb-6">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-brand-blue to-brand-purple flex items-center justify-center font-display font-bold text-lg">
                N
              </div>
              <span className="font-display font-bold text-xl tracking-tighter uppercase">Nu Graph</span>
            </a>
            <p className="text-gray-400 max-w-sm text-lg leading-relaxed mb-6">
              The New Shape of Social. Specializing in High-Performance Visual Content Strategy for DTC Sustainability and Eco-Friendly Brands.
            </p>
            <div className="mb-8 space-y-2">
              <p className="text-sm text-white/60">Email: <a href="mailto:umerimammaqbool@gmail.com" className="text-white hover:text-brand-cyan transition-colors">umerimammaqbool@gmail.com</a></p>
              <p className="text-sm text-white/60">Whatsapp: <a href="https://wa.me/923140008001" className="text-white hover:text-brand-cyan transition-colors">+923140008001</a></p>
            </div>
            <div className="flex gap-4">
              {[Twitter, Instagram, Linkedin, Github].map((Icon, i) => (
                <a key={i} href="#" className="p-3 rounded-full bg-white/5 hover:bg-white/10 text-white transition-colors">
                  <Icon size={20} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-display font-bold text-lg mb-6">Services</h4>
            <ul className="flex flex-col gap-4 text-gray-400">
              <li><a href="#" className="hover:text-brand-cyan transition-colors">Short-Form Content</a></li>
              <li><a href="#" className="hover:text-brand-purple transition-colors">Paid Advertising</a></li>
              <li><a href="#" className="hover:text-brand-blue transition-colors">AI Systems</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Visual Branding</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-bold text-lg mb-6">Agency</h4>
            <ul className="flex flex-col gap-4 text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors">Our Work</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Process</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Client Logins</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center gap-6 pt-12 border-t border-white/5 text-gray-500 text-sm">
          <p>&copy; 2026 Nu Graph Agency. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
